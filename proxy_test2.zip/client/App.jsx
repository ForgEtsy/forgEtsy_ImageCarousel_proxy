import React from 'React';
import axios from 'axios';
import Style from './App.css';

class App extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      test: 'Not Hello World'
    }
  }

  }

  render(){
    return (
      <div>
        <h1>Hello World</h1>
        <h2>Another header</h2>
        <h3 className={Style.test}>One more</h3>
      </div>
    )
  }
}

export default App;